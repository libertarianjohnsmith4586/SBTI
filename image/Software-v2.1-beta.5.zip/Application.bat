start compiler.exe gc.txt
